'use client'
import React from 'react'
import Header from '../../components/Header'
import Footer from '../../components/Footer'
import useRequireAuth from '../../hooks/useRequireAuth'
import { useAuth } from '../../context/AuthContext'

export default function DefaultPage(){
  const { user } = useRequireAuth('/login')
  const { logout } = useAuth()
  if(!user) return <div className="p-8">Redirecionando...</div>
  return (
    <div className="min-h-screen bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100">
      <Header onLogout={logout} />
      <main className="container mx-auto p-6">
        <h2 className="text-2xl font-bold">Dashboard</h2>
        <p>Área protegida. Usuário: {user.username}</p>
      </main>
      <Footer />
    </div>
  )
}
