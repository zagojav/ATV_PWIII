'use client'
import React from 'react'
import Header from '../components/Header'
import Footer from '../components/Footer'
import { useTheme } from '../context/ThemeContext'
import { useAuth } from '../context/AuthContext'
import { useRouter } from 'next/navigation'

export default function Home(){
  const { isDark, toggleTheme } = useTheme()
  const { user, logout } = useAuth()
  const router = useRouter()
  return (
    <div className="min-h-screen bg-white dark:bg-gray-800 text-gray-900 dark:text-gray-100">
      <Header onLogout={logout} />
      <main className="container mx-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-3xl font-bold">Página Principal</h2>
          <div>
            <button onClick={toggleTheme} className="mr-4 p-2 border rounded">{isDark ? 'Tema Claro' : 'Tema Escuro'}</button>
            {user ? <span>Olá, {user.username}</span> : <button onClick={()=>router.push('/login')} className="p-2 border rounded">Entrar</button>}
          </div>
        </div>

        <section className="mb-6">
          <h3 className="text-2xl font-semibold mb-2">Seção 1 — Apresentação</h3>
          <p>Bem-vindo ao sistema. Aqui há uma breve apresentação do projeto e instruções.</p>
        </section>

        <section className="mb-6">
          <h3 className="text-2xl font-semibold mb-2">Seção 2 — Funcionalidades</h3>
          <ul className="list-disc ml-6">
            <li>Autenticação com lembrar-me</li>
            <li>Tema claro/escuro</li>
            <li>Componentes Header, Footer e Loading</li>
          </ul>
        </section>

        <section className="mb-6">
          <h3 className="text-2xl font-semibold mb-2">Seção 3 — Documentação Rápida</h3>
          <p>Leia o README para instruções de execução e credenciais de teste.</p>
        </section>
      </main>
      <Footer />
    </div>
  )
}
