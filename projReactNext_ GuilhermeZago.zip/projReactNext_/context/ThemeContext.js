'use client'
import React, { createContext, useContext, useState, useEffect } from 'react'

const ThemeContext = createContext()

export function useTheme(){ return useContext(ThemeContext) }

export function ThemeProvider({children}){
  const [isDark, setIsDark] = useState(false)
  useEffect(()=>{
    const saved = typeof window !== 'undefined' && localStorage.getItem('theme') === 'dark'
    setIsDark(saved)
    if(saved) document.documentElement.classList.add('dark')
  },[])
  const toggleTheme = ()=>{
    setIsDark(prev=>{
      const next = !prev
      if(typeof window !== 'undefined'){
        localStorage.setItem('theme', next ? 'dark' : 'light')
        if(next) document.documentElement.classList.add('dark')
        else document.documentElement.classList.remove('dark')
      }
      return next
    })
  }
  return (
    <ThemeContext.Provider value={{isDark, toggleTheme}}>
      {children}
    </ThemeContext.Provider>
  )
}
